<?php 
 
 $con = mysqli_connect("localhost","root","","barang") or die("Couldn't connect");

?>